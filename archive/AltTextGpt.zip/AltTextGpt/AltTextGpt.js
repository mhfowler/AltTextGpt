/**
 * This JS file is only loaded when the ProcessHello module is run
 *
 * You should delete it if you have no javascript to add.
 *
 */

jQuery(document).ready(function($) {
	// do something
}); 
